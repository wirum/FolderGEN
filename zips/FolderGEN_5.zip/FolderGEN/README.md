# FolderGEN

Crie estruturas inteiras de projetos (pastas e arquivos) a partir de uma descrição simples em Markdown.

## Ideia

Em vez de criar pastas e arquivos manualmente, você escreve algo assim:

```md
# MeuProjeto

- src/
  - main.py
  - utils/
    - __init__.py
- tests/
  - test_main.py
- README.md
- requirements.txt
```

E o FolderGEN cria tudo isso automaticamente no seu sistema de arquivos.

## Sintaxe

- A primeira linha do arquivo deve ser `# NomeDoProjeto` — define a pasta raiz.
- Cada item é uma linha iniciada por `- `.
- Um item terminado em `/` é uma **pasta**.
- Um item sem `/` no final é um **arquivo**.
- A indentação (múltiplos de 2 espaços) define a hierarquia.
- Linhas em branco são ignoradas.

## Como executar

Requer apenas Python 3.10+ (nenhuma dependência externa).

```bash
# Criar projeto a partir de um arquivo Markdown
python src/main.py templates/python_basic.md --dest ./meu-destino

# Ou usar o menu interativo
python src/main.py
```

O fluxo é:

```text
Ler Markdown → Parsear → Validar → Mostrar estrutura → Confirmar → Criar projeto
```

## Estrutura do repositório

```text
FolderGEN/
├── src/
│   ├── main.py         # CLI
│   ├── parser.py        # Markdown -> árvore
│   ├── validator.py     # Validação e segurança
│   └── generator.py     # Árvore -> arquivos/pastas reais
├── templates/
│   └── python_basic.md
├── tests/
├── docs/
├── README.md
├── LICENSE
├── CONTRIBUTING.md
└── .gitignore
```

## Segurança

O `validator.py` bloqueia nomes que tentem escapar do diretório de destino (`../`), caminhos absolutos, caracteres inválidos e itens duplicados, antes que qualquer arquivo seja criado.

## Status

MVP funcional via CLI. Uma GUI é um objetivo futuro — por isso a lógica principal (`parser`, `validator`, `generator`) não depende da CLI.

## Contribuindo

Veja [CONTRIBUTING.md](CONTRIBUTING.md).

## Licença

Veja [LICENSE](LICENSE).
