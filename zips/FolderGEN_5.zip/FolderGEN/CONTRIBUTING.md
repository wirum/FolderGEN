# Contribuindo com o FolderGEN

Obrigado por considerar contribuir! Este é um projeto em estágio de MVP, então há bastante espaço para melhorias.

## Como contribuir

1. Faça um fork do repositório.
2. Crie uma branch descritiva: `git checkout -b feature/nome-da-feature`.
3. Faça suas alterações mantendo o estilo do código existente.
4. Adicione testes para qualquer novo comportamento, sempre que possível.
5. Abra um Pull Request explicando o que foi feito e por quê.

## Diretrizes de código

- Use Python moderno com type hints quando fizer sentido.
- Funções pequenas, com responsabilidade única.
- Prefira `pathlib` a manipulação manual de strings de caminho.
- Mantenha `parser.py`, `validator.py` e `generator.py` independentes da CLI (`main.py`), para permitir uma futura GUI.
- Erros devem sempre ter mensagens claras, indicando a linha ou o item problemático quando possível.

## Reportando bugs ou sugerindo features

Abra uma issue descrevendo:

- O comportamento esperado.
- O comportamento observado.
- Um exemplo mínimo de arquivo Markdown que reproduz o problema (se aplicável).

## Ideias futuras (fora do escopo do MVP)

- Interface gráfica (GUI).
- Suporte a templates com variáveis (ex: `{{nome_do_pacote}}`).
- Exportar/importar estruturas existentes de um diretório para Markdown.
